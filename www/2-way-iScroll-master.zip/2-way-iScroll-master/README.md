2-Way iScroll v2.0 beta
=======================

2-Way iScroll lets you swipe through a virtually infinite number of vertically scrollable pages.

The script is based on [iScroll lite](http://cubiq.org/iscroll-4). It uses only one iScroll instance for both horizontal swiping and vertical scrolling. The number of pages is limited to the device memory, the script itself has a very small footprint.